//
//  HandTrackingView.swift
//  IHope
//
//  Created by Khang Ho on 2/15/25.
//

import SwiftUI
import AVFoundation

struct HandTrackingView: View {
    var body: some View {
        ZStack {
            // Camera Preview
            CameraView()
                .edgesIgnoringSafeArea(.all)

            // UI Overlay
            VStack {
                Text("Nature Land")
                    .font(.title)
                    .bold()
                    .padding()
                    .background(Color.black.opacity(0.5))
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
    }
}

// Camera Preview Component
struct CameraView: UIViewControllerRepresentable {
    @StateObject private var handTracking = HandTracking()

    func makeUIViewController(context: Context) -> UIViewController {
        let controller = UIViewController()
        
        let previewLayer = AVCaptureVideoPreviewLayer(session: handTracking.captureSession)
        previewLayer.videoGravity = .resizeAspectFill
        // Set the frame to the view's bounds rather than the whole screen
        previewLayer.frame = controller.view.bounds
        
        // Force the preview orientation to landscape
        if let connection = previewLayer.connection, connection.isVideoOrientationSupported {
            connection.videoOrientation = .landscapeRight  // or .landscapeLeft if preferred
        }
        
        controller.view.layer.addSublayer(previewLayer)
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {
        // Update the preview layer frame and orientation in case of layout changes
        if let previewLayer = uiViewController.view.layer.sublayers?.first as? AVCaptureVideoPreviewLayer,
           let connection = previewLayer.connection, connection.isVideoOrientationSupported {
            previewLayer.frame = uiViewController.view.bounds
            connection.videoOrientation = .landscapeRight
        }
    }
}
