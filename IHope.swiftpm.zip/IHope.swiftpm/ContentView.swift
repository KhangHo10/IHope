import SwiftUI

struct ContentView: View {
    @State private var userName: String = ""
    @State private var animateGradient: Bool = false
    
    private let startColor: Color = .blue
    private let endColor: Color = .green
    
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [startColor, endColor], startPoint: .topLeading, endPoint: .bottomTrailing)
                    .edgesIgnoringSafeArea(.all)
                    .hueRotation(.degrees(animateGradient ? 45 : 0))
                    .onAppear {
                        withAnimation(.easeInOut(duration: 3).repeatForever(autoreverses: true)) {
                            animateGradient.toggle()
                        }
                    }
                    
                
                Image("TreeBackground")
                    .resizable()
                    .ignoresSafeArea()
                
                
                VStack (spacing: 20){
                    Text("Welcome to IHope")
                        .font(.system(size: 40))
                        .fontWeight(.black)
                        .foregroundColor(.white)
                        .padding(.top, 100)
                    
                    TextField("Enter your name", text: $userName)
                        .padding()
                        .background(Color(red: 0/255, green: 35/255, blue: 64/255))
                        .cornerRadius(25)
                        .padding()
                        .frame(width: 264, height: 70)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                    
                    NavigationLink(destination: InstructionView(userName: userName)) {
                        Text("Start")
                            .font(.system(size: 18))
                            .fontWeight(.black)
                            .foregroundColor(.white)
                            .frame(width: 140, height: 40)
                            .background(Color(hex: "#011831"))
                            .cornerRadius(25)
                    }
                        
                }
                .padding()
                .frame(maxHeight: .infinity, alignment: .top)
            }
        }
    }
}

extension Color {
    init(hex: String) {
        let hex = hex.replacingOccurrences(of: "#", with: "")
        let scanner = Scanner(string: hex)
        var rgb: UInt64 = 0
        scanner.scanHexInt64(&rgb)
        
        self.init(
            .sRGB,
            red: Double((rgb & 0xFF0000) >> 16) / 255.0,
            green: Double((rgb & 0x00FF00) >> 8) / 255.0,
            blue: Double(rgb & 0x0000FF) / 255.0,
            opacity: 1.0
        )
    }
}
