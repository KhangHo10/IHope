//
//  ModeView.swift
//  IHope
//
//  Created by Khang Ho on 2/14/25.
//

import SwiftUI

struct ModeView: View {
    @State private var animateGradient: Bool = false
    
    let userName: String
    private let startColor: Color = .blue
    private let endColor: Color = .green
    
    var body: some View{
        NavigationStack {
            ZStack {
                LinearGradient(colors: [startColor, endColor], startPoint: .topLeading, endPoint: .bottomTrailing)
                    .edgesIgnoringSafeArea(.all)
                    .hueRotation(.degrees(animateGradient ? 45 : 0))
                    .onAppear {
                        withAnimation(.easeInOut(duration: 3).repeatForever(autoreverses: true)) {
                            animateGradient.toggle()
                        }
                    }
                
                VStack(spacing: 80){
                    Text("Mode")
                        .frame(width: 317, height: 85)
                        .background(RoundedRectangle(cornerRadius: 25).stroke(Color.blue, lineWidth: 8))
                        .font(.system(size: 40))
                        .fontWeight(.black)
                        .foregroundColor(.white)
                        .padding(.top, 100)
                    
                    Text("Welcome \(userName) to IHope, please choose one of the modes below here!")
                        .font(.system(size: 25))
                        .fontWeight(.black)
                        .foregroundColor(.white)
                        .offset(x: -100)
                    
                    HStack(spacing: 80){
                        VStack {
                            Image("Nature Mode")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 320, height: 320)
                            
                            Button(action: {
                                print("Button Pressed!")
                            }) {
                                Text("Green Land")
                                    .font(.system(size: 36))
                                    .fontWeight(.black)
                                    .foregroundColor(.white)
                                    .frame(width: 228, height: 66)
                                    .background(Color.green)
                                    .cornerRadius(25)
                            }
                        }
                        
                        VStack {
                            Image("Snow Mode")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 275, height: 220)
                                .overlay(Color.black.opacity(0.5))
                            
                            Button(action: {
                                print("Button Pressed!")
                            }) {
                                Text("Snow Land")
                                    .font(.system(size: 36))
                                    .fontWeight(.black)
                                    .foregroundColor(.cyan)
                                    .frame(width: 228, height: 66)
                                    .background(Color.white)
                                    .cornerRadius(25)
                                    .offset(y: 50)
                            }
                        }
                        
                        VStack {
                            Image("Volcano Mode")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 320, height: 220)
                                .overlay(Color.black.opacity(0.5))
                            
                            Button(action: {
                                print("Button Pressed!")
                            }) {
                                Text("Fire Land")
                                    .font(.system(size: 36))
                                    .fontWeight(.black)
                                    .foregroundColor(.orange)
                                    .frame(width: 228, height: 66)
                                    .background(Color.brown)
                                    .cornerRadius(25)
                                    .offset(y: 50)
                            }
                        }
                    }
                }
                
                
                
                .padding()
                .frame(maxHeight: .infinity, alignment: .top)
            }
        }
    }
}

struct ModeView_Previews: PreviewProvider {
    static var previews: some View {
        ModeView(userName: "Khang")
    }
}

