//
//  InstructionView.swift
//  IHope
//
//  Created by Khang Ho on 2/13/25.
//

import SwiftUI

struct InstructionView: View {
    @State private var animateGradient: Bool = false
    
    let userName: String
    private let startColor: Color = .blue
    private let endColor: Color = .green
    
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [startColor, endColor], startPoint: .topLeading, endPoint: .bottomTrailing)
                    .edgesIgnoringSafeArea(.all)
                    .hueRotation(.degrees(animateGradient ? 45 : 0))
                    .onAppear {
                        withAnimation(.easeInOut(duration: 3).repeatForever(autoreverses: true)) {
                            animateGradient.toggle()
                        }
                    }
                
                VStack(spacing: 6){
                    ZStack {
                        Text("Instruction")
                            .frame(width: 317, height: 85)
                            .background(RoundedRectangle(cornerRadius: 25).stroke(Color.blue, lineWidth: 8))
                            .font(.system(size: 40))
                            .fontWeight(.black)
                            .foregroundColor(.white)
                            .padding(.top, 20)
                        
                        HStack {
                            Spacer()
                            NavigationLink(destination: ModeView(userName: userName)) {
                                Text("Next")
                                    .font(.system(size: 18))
                                    .fontWeight(.black)
                                    .foregroundColor(.white)
                                    .frame(width: 140, height: 40)
                                    .background(Color(hex: "#011831"))
                                    .cornerRadius(25)
                                    .offset(x: -50, y: 20)
                            }
                        }
                    }
                    
                    HStack(spacing: 120){
                        Text("Step One")
                            .font(.system(size: 30))
                            .fontWeight(.black)
                            .foregroundColor(.white)
                            .underline()
                            
                        Text("- Enable camera access in the setting.")
                            .font(.system(size: 25))
                            .fontWeight(.black)
                            .foregroundColor(.white)
                            .offset(x: 30)
                        
                        Image("Setting Camera")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 240, height: 240)
                            .offset(x: -5)
                                                
                        
                    }
                    
                    HStack(spacing: 140){
                        Text("Step Two")
                            .font(.system(size: 30))
                            .fontWeight(.black)
                            .foregroundColor(.white)
                            .underline()
                            .offset(x: -7)
                        
                        Text("- Choose desire environments such as nature, snow, or volcano by pressing on the image.")
                            .font(.system(size: 25))
                            .fontWeight(.black)
                            .foregroundColor(.white)
                            .frame(width: 420, height: 200)
                        
                            Image("Modes")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 240, height: 240)
                    }
                    
                    HStack(spacing: 120){
                        Text("Step Three")
                            .font(.system(size: 30))
                            .fontWeight(.black)
                            .foregroundColor(.white)
                            .underline()
                            .offset(x: -18)
                        
                        Text("- The two light-color circles will trace your fingers, and you can double-tap your finger to interact with the background.")
                            .font(.system(size: 25))
                            .fontWeight(.black)
                            .foregroundColor(.white)
                            .frame(width: 420, height: 200)
                        
                        Image("Hand Instruction")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 240, height: 240)
                            .offset(x: 8)
                    }
                }
                
                .padding()
                .frame(maxHeight: .infinity, alignment: .top)
            }
        }
    }
}

struct InstructionView_Previews: PreviewProvider {
    static var previews: some View {
        InstructionView(userName: "Khang")
    }
}

