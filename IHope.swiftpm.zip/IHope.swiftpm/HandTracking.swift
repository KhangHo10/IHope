//
//  HandTracking.swift
//  IHope
//
//  Created by Khang Ho on 2/15/25.
//

import AVFoundation
import Vision
import SwiftUI

class HandTracking: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate, ObservableObject {
    var captureSession: AVCaptureSession!
    private var handPoseRequest: VNDetectHumanHandPoseRequest = {
        let request = VNDetectHumanHandPoseRequest()
        request.maximumHandCount = 2
        return request
    }()
    
    // Debounce flags to ensure we only trigger once per gesture
    private var rightSoundTriggered = false
    private var leftSoundTriggered = false

    override init() {
        super.init()
        setupCamera()
    }

    private func setupCamera() {
        captureSession = AVCaptureSession()
        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front),
              let input = try? AVCaptureDeviceInput(device: device) else {
            print("Error setting up camera input")
            return
        }
        captureSession.addInput(input)

        let videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.addOutput(videoOutput)

        captureSession.startRunning()
    }

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        processHandPose(pixelBuffer)
    }

    private func processHandPose(_ pixelBuffer: CVPixelBuffer) {
        let requestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
        do {
            try requestHandler.perform([handPoseRequest])
            if let results = handPoseRequest.results {
                analyzeHandPose(results)
            }
        } catch {
            print("Hand tracking failed: \(error)")
        }
    }

    private func analyzeHandPose(_ observations: [VNHumanHandPoseObservation]) {
        if observations.isEmpty { return }
        
        if observations.count == 1 {
            // Only one hand detected. Use threshold as a fallback.
            let hand = observations[0]
            if let points = try? hand.recognizedPoints(.all) {
                let avgX = points.values.reduce(0, { $0 + $1.location.x }) / CGFloat(points.count)
                if avgX < 0.5 {
                    // Treat as left-hand if mostly on the left side.
                    processTwoHandGestures(leftHand: hand, rightHand: hand)
                } else {
                    // Or treat as right-hand.
                    processTwoHandGestures(leftHand: hand, rightHand: hand)
                }
            }
        } else {
            // Two (or more) hands detected. Compute and compare their average x values.
            var handsWithAvgX: [(observation: VNHumanHandPoseObservation, avgX: CGFloat)] = []
            for hand in observations {
                if let points = try? hand.recognizedPoints(.all) {
                    let avgX = points.values.reduce(0, { $0 + $1.location.x }) / CGFloat(points.count)
                    handsWithAvgX.append((observation: hand, avgX: avgX))
                }
            }
            // Sort by average x coordinate.
            handsWithAvgX.sort { $0.avgX < $1.avgX }
            
            // The hand with the lower average x is assumed to be the left hand.
            let leftHandObservation = handsWithAvgX.first?.observation
            // The hand with the higher average x is assumed to be the right hand.
            let rightHandObservation = handsWithAvgX.last?.observation
            
            if let leftHand = leftHandObservation, let rightHand = rightHandObservation {
                processTwoHandGestures(leftHand: leftHand, rightHand: rightHand)
            }
        }
    }

    private func processTwoHandGestures(leftHand: VNHumanHandPoseObservation,
                                        rightHand: VNHumanHandPoseObservation) {
        do {
            // Extract left-hand points
            let leftThumb = try leftHand.recognizedPoint(.thumbTip)
            let leftIndex = try leftHand.recognizedPoint(.indexTip)
            
            // Extract right-hand points
            let rightThumb = try rightHand.recognizedPoint(.thumbTip)
            let rightIndex = try rightHand.recognizedPoint(.indexTip)
            
            // For right hand: trigger only once when the gesture starts, and reset when released.
            if isTouching(rightThumb, rightIndex) {
                if !rightSoundTriggered {
                    print("Right touching")
                    rightSoundTriggered = true
                }
            } else {
                // Reset when fingers are not touching.
                rightSoundTriggered = false
            }
            
            // Similarly for left hand.
            if isTouching(leftThumb, leftIndex) {
                if !leftSoundTriggered {
                    print("Left touching")
                    leftSoundTriggered = true
                }
            } else {
                leftSoundTriggered = false
            }
            
        } catch {
            print("Error processing hand points: \(error)")
        }
    }

    private func isTouching(_ point1: VNRecognizedPoint, _ point2: VNRecognizedPoint, threshold: CGFloat = 0.06) -> Bool {
        let distance = hypot(point1.location.x - point2.location.x, point1.location.y - point2.location.y)
        return distance < threshold
    }

    private func isBent(_ tip: VNRecognizedPoint, _ pip: VNRecognizedPoint, _ mcp: VNRecognizedPoint, angleThreshold: CGFloat = 90) -> Bool {
        let angle = calculateAngle(tip, pip, mcp)
        return angle < angleThreshold
    }

    private func calculateAngle(_ tip: VNRecognizedPoint, _ pip: VNRecognizedPoint, _ mcp: VNRecognizedPoint) -> CGFloat {
        let vector1 = CGPoint(x: pip.location.x - mcp.location.x, y: pip.location.y - mcp.location.y)
        let vector2 = CGPoint(x: tip.location.x - pip.location.x, y: tip.location.y - pip.location.y)

        let dotProduct = vector1.x * vector2.x + vector1.y * vector2.y
        let magnitude1 = hypot(vector1.x, vector1.y)
        let magnitude2 = hypot(vector2.x, vector2.y)

        let angle = acos(dotProduct / (magnitude1 * magnitude2)) * (180 / .pi)
        return angle
    }
}
