//
//  NatureView.swift
//  IHope
//
//  Created by Khang Ho on 2/14/25.
//

import SwiftUI
import SceneKit

struct NatureView: View {
    @State var models = [
        Model(id: 0, name: "Poly Tree", modelName: "TreeOne.usdz"),
        Model(id: 1, name: "Poly Tree 2", modelName: "TreeTwo.usdz")
    ]
    
    @State var index = 0
    
    var body: some View {
        VStack {
            // SceneView with SceneKit integration
            SceneView(scene: createScene(), options: [.autoenablesDefaultLighting, .allowsCameraControl])
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height / 2)
            Spacer(minLength: 0)
        }
    }
    
    // Function to create a SceneKit scene
    func createScene() -> SCNScene {
        let scene = SCNScene()
        
        // Add camera
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(0, 5, 15)
        scene.rootNode.addChildNode(cameraNode)
        
        // Add lighting
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light?.type = .omni
        lightNode.position = SCNVector3(0, 10, 10)
        scene.rootNode.addChildNode(lightNode)
        
        // Load and add the model from the .usdz file
        if let modelScene = SCNScene(named: models[index].modelName) {
            let modelNode = modelScene.rootNode.clone()
            scene.rootNode.addChildNode(modelNode)
            print("Model loaded successfully!")
        } else {
            print("Failed to load .usdz model")
        }
        
        // Add a simple geometry (box) for testing visibility
        let box = SCNBox(width: 1, height: 1, length: 1, chamferRadius: 0)
        let boxNode = SCNNode(geometry: box)
        boxNode.position = SCNVector3(0, 0, 0) // Position the box at the center
        scene.rootNode.addChildNode(boxNode)
        
        return scene
    }
}

struct Model: Identifiable {
    var id: Int
    var name: String
    var modelName: String
}

struct NatureView_Previews: PreviewProvider {
    static var previews: some View {
        NatureView()
    }
}
